import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';


@Component({
  selector: 'app-mine',
  templateUrl: './mine.component.html',
  styleUrls: ['./mine.component.css']
})
export class MineComponent implements OnInit {
  answer:number
  constructor(private _http: HttpService) { }

  ngOnInit() {
    this.answer = 0;
  }

  process(){
    this._http.transaction.method = "Mine"
  }
  onSubmit(){
    console.log(this.answer);
    if(this.answer == 10){
      this._http.amtCoins += 1;
      this._http.curVal += 1;
      this._http.createTransaction("Mine",1);
      // this.ngOnInit();
      console.log(this._http.ledger)
    }
  }

}

import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  pets: any;
  petdetail: any;
  petToEdit: any;

  constructor(private _httpService: HttpService) { }

  ngOnInit() {
    this.AllPets();
  }
AllPets() {
  this._httpService.AllPets().subscribe(data => { this.pets = data;
  });
  console.log(this.AllPets);
}
// Details(id) {
//   this._httpService.readPet(id).subscribe(data => {this.pets = data;
//   });
//   console.log(this.AllPets);
// }

// Delete(id) {
//   this._httpService.deletePet(id).subscribe(data => {
//     if (data['status'] === 'gucci') {
//       this.ngOnInit();
//       console.log(this.AllPet);
//     } else {
//       console.log('didnt work!');
//     }
//   });
}

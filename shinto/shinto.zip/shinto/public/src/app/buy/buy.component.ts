import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-buy',
  templateUrl: './buy.component.html',
  styleUrls: ['./buy.component.css']
})
export class BuyComponent implements OnInit {
  value:number;
  amount:number;
  currentCoins:number;
  constructor(private _http: HttpService) {
    this.value = this._http.curVal;
    this.currentCoins = this._http.amtCoins;
  }

  ngOnInit() {
  }

  onSubmit(){
    this._http.createTransaction("Purchase",this.amount)
    this._http.amtCoins+=this.amount;
    this._http.curVal+=this.amount;
    this.value = this._http.curVal;
    this.currentCoins = this._http.amtCoins;
    this.amount = 0;
  }

}

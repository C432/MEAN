import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class HttpService {
  constructor(private _http: HttpClient) {}

  createPet(newPet) {
    return this._http.post('/pet', newPet);
  }

  getOnePet(id) {
    return this._http.get('/api/pet/' + id);
  }

  AllPets() {
    return this._http.get('/api/pet');
  }

  deletePet(id) {
    return this._http.delete('/delete/ + id');
  }

  editPet(id, pet) {
    return this._http.patch('/pet/' + id, pet);
  }
}

import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { Route, Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
  pet: any;
  message: '';
  errors: {
    name: '',
    type: '',
    description: ''
  };

  constructor(
    private _httpService: HttpService,
    private _router: Router) {
      this.clear();
    }

  ngOnInit() {}
  clear () {
    this.pet = {
      name: '',
      type: '',
      description: '',
      skill1: '',
      skill2: '',
      skill3: '',
    };
  }
onSubmit() {
  this._httpService.createPet(this.pet).subscribe(data => {
    if ('errors' in data) {
      console.log('errors!');
      this.errors = data['errors']['name']['message'];
    } else {
      this.pet = { name: '', type: '', description: '', skill1: '', skill2: '', skill3: '' };
      console.log(data);
      this._router.navigate(['/home']);
    }
  });
}

}

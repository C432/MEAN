import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  errors = [];
  oldPet: any;
  freshPet: any;

  constructor(private _http: HttpService, private _router: Router, private _route: ActivatedRoute) { }

  ngOnInit() {
    this.oldPet={
      "name": "",
      "type": "",
      "description": "",
    }
    this.freshPet={
      "name": "",
      "type": "",
      "description": "",
    }
    this._route.params.subscribe((params: Params)=>{
      this.getOne(params['id'])
    });
  }
  getOne(id){
    this._http.onePet(id).subscribe(data=>{
      this.oldPet = data;
    })
  }
  editOldPet(){
    this._http.updatePet(this.oldPet._id, this.oldPet).subscribe(data=>{
      if('errors' in data){
        this.errors = [];
        for(let key in data['errors']){
          this.errors.push(data['errors'][key].message);
        }
      }
      else{
        this.freshPet = data;
        this.oldPet = {name: "", type: "", description: "", skill1: "", skill2: "", skill3: ""};
        this._router.navigate(['/details/', this.freshPet._id]);
      }
    })
  }

}

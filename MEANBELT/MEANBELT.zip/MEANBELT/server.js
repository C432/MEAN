const express = require("express");
const app = express();
const bodyParser = require("body-parser");
app.use(bodyParser.json()); // safter express is declare

const path = require("path");
app.use(express.static(__dirname + "/public/dist/public")) // angular static folder step 4

const mongoose = require("mongoose");
const router = require("./server/routes");
router(app);

app.all("*", (req, res, next) => {
    res.sendFile(path.resolve("/public/dist/public/index.html"));
});
app.listen(8000, function() {
  console.log("on 8000!");
});

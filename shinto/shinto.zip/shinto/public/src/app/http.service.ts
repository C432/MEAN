import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  amtCoins= 0;
  curVal = 1;
  ledger = [];
  transaction:any;

  constructor(private _http: HttpClient) {
    // this.curVal = 1;
    this.transaction = {
      id:0,
      method:"",//how?
      amount:0,//number of coin we mined, purchases, or sold
      value:0
    }
   }

   createTransaction(method:string, amount:number){
     this.transaction.id = Math.floor(Math.random()*1000);
     this.transaction.method = method;
     this.transaction.amount = amount;
     this.transaction.value = this.curVal;
     this.ledger.push(this.transaction);
     this.transaction = {
      id:0,
      method:"",//how?
      amount:0,//number of coin we mined, purchases, or sold
      value:0
    }
   }


}

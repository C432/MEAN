import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient) { }
  createPet(data){
    return this._http.post('/api/pets', data)
  }
  allPets(){
    return this._http.get('/api/pets')
  }
  onePet(id){
    return this._http.get('/api/pets/'+id)
  }
  deleteOne(id){
    return this._http.delete('/api/pets/'+id)
  }
  updatePet(id, data){
    return this._http.patch('/api/pets/'+id, data)
  }
  newLike(id, data){
    return this._http.patch('/api/pets/like/'+id, data)
  }
}

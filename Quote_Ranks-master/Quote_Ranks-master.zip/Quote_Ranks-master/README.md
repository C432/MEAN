# Quote Ranks
A Full-MEAN application where a user can submit quotes and vote for them

# Instructions

In your command line terminal, navigate to the Quote Ranks project folder and install the npm packages:

```
sudo npm install
```

In a seperate terminal tab/window, have mongod running:

```
sudo mongod
```

Run server.js in the Quote Ranks project folder using node, nodemon, or pm2, etc.:

```
sudo node server.js
```

Navigate to localhost:8000 in your internet browser.

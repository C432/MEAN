// import { Component, OnInit } from '@angular/core';
// import { HttpService } from '../http.service';
// import { ActivatedRoute, Params, Router } from '@angular/router';

// @Component({
//   selector: 'app-edit',
//   templateUrl: './edit.component.html',
//   styleUrls: ['./edit.component.css']
// })
// export class EditComponent implements OnInit {
//   OnePet: any;
//   editPet: any;
//   // editPet: {
//   //   name: any,
//   //   type: any,
//   //   description: any,
//   //   skills: any,
//   // };
//   errors: any;

//   constructor(
//     private _httpService: HttpService,
//     private _route: ActivatedRoute,
//     private _router: Router,
//   ) { }

//   ngOnInit() {
//     this._route.params.subscribe((params: Params) => {
//       this.getOne(params['id']);
//       console.log(params['id']);
//     });
//   }
// getOne(id) {
//   this._httpService.readOne(id).subscribe(data => {
//     if (data === null || 'kind' in data) {
//       this._router.navigate(['/home']);
//     } else {
//       this.OnePet = data;
//       console.log('get one pet', this.OnePet);
//     }
//   });

  // EditPet(){
  //   this._httpService.edit(this.OnePet._id, this.OnePet).subscribe(data => {
  //     if ('errors' in data) {
  //       console.log(data['errors']['name']['message']);
  //       this.errors = data['errors']['name']['message'];
  //     } else {
  //       this.editPet = data;
  //       this.OnePet.name = '';
  //       this._router.navigate(['/home']);
  //       console.log('update', this.editPet);
  //     }
  //   });
//   }
// }
// }

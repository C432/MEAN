import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  isDisabled: boolean;
  onePet: any;

  constructor(private _http: HttpService, private _route: ActivatedRoute, private _router: Router) { }

  ngOnInit() {
    this._route.params.subscribe((params: Params)=>{
      this.getOne(params['id'])
    });
    this.isDisabled = false;
    this.onePet={
      "name": "",
      "type": "",
      "description": "",
    };
  }
  getOne(id){
    this._http.onePet(id).subscribe(data=>{
      this.onePet = data;
    })
  }
  deletePet(id){
    this._http.deleteOne(id).subscribe(data=>{
      this._router.navigate(['/home'])
    })
  }
  likePet(id){
    this._http.newLike(this.onePet._id, this.onePet).subscribe(data=>{
      this.onePet = data;
      this.isDisabled = true;
      this.getOne(id);
    })
  }

}

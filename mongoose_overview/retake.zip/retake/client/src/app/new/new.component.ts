import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { Router } from '@angular/router'

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
  errors=[];
  newPet: any;

  constructor(private _http: HttpService, private _router: Router) { }

  ngOnInit() {
    this.newPet = {name: "", type: "", description: "", skill1: "", skill2: "", skill3: ""};
    this.errors = [];
  }

  addPet(){
    this._http.createPet(this.newPet).subscribe(data=>{
      if('errors' in data){
        this.errors = [];
        for(let key in data['errors']){
          this.errors.push(data['errors'][key].message);
        }
      }
      else{
        this.newPet = {name: "", type: "", description: "", skill1: "", skill2: "", skill3: ""};
        this._router.navigate(['/home']);
      }
    });
  }

}
